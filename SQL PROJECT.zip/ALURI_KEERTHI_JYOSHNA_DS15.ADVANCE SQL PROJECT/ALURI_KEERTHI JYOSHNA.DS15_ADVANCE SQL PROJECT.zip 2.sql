SELECT * FROM moviedb.rating;

##1.Write a SQL query to find those reviewers who have rated nothing for some movies. Return reviewer name.

SELECT DISTINCT rev_name 
FROM reviewer 
WHERE rev_id IN (
SELECT rev_id 
FROM rating 
WHERE rev_stars = 0);

##The reviewers who had not rated nothing for movies are Neal Wruck and Scott LeBrun.

##2.Write a SQL query to find the movies, which have been reviewed by any reviewer body except by 'Paul Monks'. Return movie title.
select * from movie;
select * from reviewer;


SELECT movie.mov_title
FROM movie 
WHERE movie.mov_id IN(
SELECT mov_id 
FROM rating 
WHERE rev_id NOT IN (
SELECT rev_id 
FROM reviewer 
WHERE rev_name='Paul Monks'));



##4.write a SQL query to find the movies directed by 'James Cameron'. Return movie title
select * from movie;
select * from  director;
select * from movie_direction;


SELECT mov_title
FROM movie
WHERE mov_id IN (
SELECT mov_id 
FROM movie_direction
WHERE dir_id IN (
SELECT dir_id 
FROM director 
WHERE dir_fname = 'James' AND dir_lname='Cameron'
));


##5.Write a query in SQL to find the name of those movies where one or more actors acted in two or more movies. 
select * from movie;
select * from movie_cast;
select * from actors;

SELECT mov_title 
FROM movie 
WHERE mov_id IN (
SELECT mov_id 
FROM movie_cast 
WHERE act_id IN (
SELECT act_id 
FROM actors
WHERE act_id IN (
SELECT act_id 
FROM movie_cast GROUP BY act_id 
HAVING COUNT(act_id)>1)));