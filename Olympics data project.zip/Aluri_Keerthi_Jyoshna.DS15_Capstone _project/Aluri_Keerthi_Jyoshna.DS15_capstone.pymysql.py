#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pymysql


# In[2]:


pip install pymysql


# In[5]:


from sqlalchemy import create_engine
import pandas as pd
import numpy as np

df1 = pd.read_csv("C:\\Users\\vinny\\OneDrive\\Desktop\\olympix_data_organized_with_header (1) (1) (1).csv")
db_connection_str = 'mysql+pymysql://root:12345@127.0.0.1/sakila1'
db_connection = create_engine(db_connection_str)
df1.to_sql("olympicsdata",db_connection)
print("data written into the table")
#print(df1.shape)


# In[ ]:




